#include <iostream>
#include <cstring>
#include "TAD_volumen.h"
#include <fstream>
#include <cmath>

 void hacer_proyeccion(int &a, int &b, int &valor,sImagen &imagenGenerada){
     for(int i = 0;i<imagenGenerada.imagen.size();i++){
         for(int j = 0;j<imagenGenerada.imagen[i].size();j++){
             if(i == a && j == b){
                 //cout<<"ESTA INSERTANDO "<<valor<<endl;
                 imagenGenerada.imagen[i][j].valorIntensidad = valor;
                 imagenGenerada.imagen[i][j].pos_i = a;
                 imagenGenerada.imagen[i][j].pos_i = b;
             }
         }
     }
 }

void crearArchivo(char* nombreA,sImagen &imagenG){
    ofstream nuevoArch;
    char nombre[20];
    strcpy(nombre,"../");
    strcat(nombre,nombreA);
    nuevoArch.open(nombre);
    nuevoArch << "P2\n";
    nuevoArch << imagenG.W;
    nuevoArch << " ";
    nuevoArch<< imagenG.H;
    nuevoArch << "\n255\n";
    for(int i = 0;i<imagenG.imagen.size();i++){
        for(int j = 0;j<imagenG.imagen[i].size();j++){
            nuevoArch << imagenG.imagen[i][j].valorIntensidad;
                nuevoArch <<" ";
        }
        nuevoArch <<"\n";
    }
    nuevoArch.close();
}

bool proyeccion2D(char* comando, struct sVolumen &volumen){
    sImagen img;
    sImagen imagenGenerada;
    int p_i, p_j, cont;
    char direccion[5];
    char criterio[10];
    char nombre_archivo[20];
    strtok(comando, " ");
    strcpy(direccion, strtok(NULL, " "));
    strcpy(criterio, strtok(NULL, " "));
    strcpy(nombre_archivo, strtok(NULL, " "));
    if(volumen.volumen.empty()){
        cout<<"No hay un volumen cargado en memoria"<<endl;
        return false;
    }else{
        if(strcmp(direccion,"x")==0){
            //inicializar la proyecc
            imagenGenerada.W = volumen.volumen.front().W;
            imagenGenerada.H = volumen.volumen.size();
            imagenGenerada.imagen.resize(volumen.volumen.front().W);
            for(int i = 0; i<imagenGenerada.imagen.size();i++){
                imagenGenerada.imagen[i].resize(volumen.volumen.size());
            }
            if(strcmp(criterio,"minimo")==0){
                int minimox = 1000;
                p_i=0;
                p_j=0;
                for(int k = volumen.volumen.size()-1; k>=0; k--){
                    cont = 0;
                    int i = 0;
                    int j = 0; //1, 2, 3, 4, 5
                    img = volumen.volumen[k];
                    while (cont != img.imagen.size()){ //hacer el mismo procedimineto por cada columna
                        for(  ; i<img.imagen.size()-1;i++){
                            if(minimox > img.imagen[i][j].valorIntensidad){
                                minimox = img.imagen[i][j].valorIntensidad;
                            }
                        }
                        hacer_proyeccion(p_i,p_j,minimox,imagenGenerada); //hace la proyeccionx cuando se haya encontrado el minimo de cada columna
                        p_j++;
                        j++;
                        cont++;
                    }
                    p_i++;
                    p_j=0;
                }
            }else if(strcmp(criterio,"maximo")==0){
                p_i=0;
                p_j=0;
                int maximox=0;
                for(int k = volumen.volumen.size()-1; k>=0; k--){
                    cont = 0;
                    int i = 0;
                    int j = 0; //1, 2, 3, 4, 5
                    img = volumen.volumen[k];
                    while (cont != img.imagen.size()){ //hacer el mismo procedimineto por cada columna
                        for(  ; i<img.imagen.size()-1;i++){
                            if(maximox < img.imagen[i][j].valorIntensidad){
                                maximox = img.imagen[i][j].valorIntensidad;
                            }
                        }
                        hacer_proyeccion(p_i,p_j,maximox,imagenGenerada); //hace la proyeccionx cuando se haya encontrado el minimo de cada columna
                        p_j++;
                        j++;
                        cont++;
                    }
                    p_i++;
                    p_j=0;
                }
            }else if(strcmp(criterio,"promedio")==0){
                p_i=0;
                p_j=0;
                int promedio=0,suma=0;
                for(int k = volumen.volumen.size()-1; k>=0; k--){
                    cont = 0;
                    int i = 0;
                    int j = 0; //1, 2, 3, 4, 5
                    img = volumen.volumen[k];
                    while (cont != img.imagen.size()){ //hacer el mismo procedimineto por cada columna
                        for(  ; i<img.imagen.size()-1;i++){
                                suma += img.imagen[i][j].valorIntensidad;
                        }
                        promedio=suma/img.imagen.size();
                        promedio=floor(promedio);
                        hacer_proyeccion(p_i,p_j,promedio,imagenGenerada); //hace la proyeccionx cuando se haya encontrado el minimo de cada columna
                        p_j++;
                        j++;
                        cont++;
                    }
                    p_i++;
                    p_j=0;
                }
            }else if(strcmp(criterio,"mediana")==0){
                int mediana,pos_mediana;
                p_i=0;
                p_j=0;
                for(int k = volumen.volumen.size()-1; k>=0; k--){
                    cont = 0;
                    int i = 0,j = 0;//1, 2, 3, 4, 5
                    img = volumen.volumen[k];
                    int mitad=img.imagen.size()/2;
                    while (cont != img.imagen.size()){ //hacer el mismo procedimineto por cada columna
                        //for(  ; i<img.imagen.size()-1;i++){
                            if(img.imagen.size()%2==0){
                                pos_mediana = (mitad+(mitad+1))/2;
                                mediana = img.imagen[pos_mediana][pos_mediana].valorIntensidad;
                            }else{
                                mediana = img.imagen[mitad][mitad].valorIntensidad;
                            }
                        //}
                        hacer_proyeccion(p_i,p_j,mediana,imagenGenerada); //hace la proyeccionx cuando se haya encontrado el minimo de cada columna
                        p_j++;
                        j++;
                        cont++;
                    }
                    p_i++;
                    p_j=0;
                }
            }else{
                cout<<"Criterio no valido"<<endl;
                return false;
            }
        }else if (strcmp(direccion,"y")==0){
            imagenGenerada.W = volumen.volumen.size();
            imagenGenerada.H = volumen.volumen.front().H;
            imagenGenerada.imagen.resize(volumen.volumen.size());
            for(int i = 0; i<imagenGenerada.imagen.size();i++){
                imagenGenerada.imagen[i].resize(volumen.volumen.front().H);
            }
            if(strcmp(criterio,"minimo")==0){
                int minimoy = 1000;
                p_i = 0;
                p_j = 0;
                for(int k = volumen.volumen.size()-1; k>=0; k--){
                    img = volumen.volumen[k];
                    cont = 0;
                    int i = 0;
                    //recorrer imagen por filas y proyeccion en columnas
                    while (cont != img.imagen.size()){
                        for(int j = 0; j<img.imagen.size();j++){ //j < alto
                            if(minimoy > img.imagen[i][j].valorIntensidad){
                                minimoy = img.imagen[i][j].valorIntensidad;
                            }
                        }
                        //hacerporyeccion
                        hacer_proyeccion(p_i,p_j, minimoy,imagenGenerada);
                        p_i++;
                        i++;
                        cont++;
                    }
                    p_j++;
                    p_i = 0;
                }

            }else if(strcmp(criterio,"maximo")==0){
                int maximoy = 0;
                p_i=0;
                p_j=0;
                for(int k = volumen.volumen.size()-1; k>=0; k--){
                    img = volumen.volumen[k];
                    cont = 0;
                    int i = 0;
                    //recorrer imagen por filas y proyeccion en columnas
                    while (cont != img.imagen.size()){
                        for(int j = 0; j<img.imagen.size();j++){ //j < alto
                            if(maximoy < img.imagen[i][j].valorIntensidad){
                                maximoy = img.imagen[i][j].valorIntensidad;
                            }
                        }
                        //hacerporyeccion
                        hacer_proyeccion(p_i,p_j, maximoy,imagenGenerada);
                        p_i++;
                        i++;
                        cont++;
                    }
                    p_j++;
                    p_i = 0;
                }
            }else if(strcmp(criterio,"promedio")==0){
                int promedioy=0,sumay=0;
                p_i=0;
                p_j=0;
                for(int k = volumen.volumen.size()-1; k>=0; k--){
                    img = volumen.volumen[k];
                    cont = 0;
                    int i = 0;
                    //recorrer imagen por filas y proyeccion en columnas
                    while (cont != img.imagen.size()){
                        for(int j = 0; j<img.imagen.size();j++){ //j < alto
                                sumay += img.imagen[i][j].valorIntensidad;
                        }
                        promedioy=sumay/img.imagen.size();
                        promedioy=floor(promedioy);
                        //hacerporyeccion
                        hacer_proyeccion(p_i,p_j, promedioy,imagenGenerada);
                        p_i++;
                        i++;
                        cont++;
                    }
                    p_j++;
                    p_i = 0;
                }
            }else if(strcmp(criterio,"mediana")==0){
                int pos_medianay=0,medianay=0;
                p_i=0;
                p_j=0;
                for(int k = volumen.volumen.size()-1; k>=0; k--){
                    img = volumen.volumen[k];
                    cont = 0;
                    int i = 0;
                    int mitady=img.imagen.size()/2;
                    //recorrer imagen por filas y proyeccion en columnas
                    while (cont != img.imagen.size()){
                        //for(int j = 0; j<img.imagen.size();j++){ //j < alto
                            if(img.imagen.size()%2==0){
                                pos_medianay = (mitady+(mitady+1))/2;
                                medianay = img.imagen[pos_medianay][pos_medianay].valorIntensidad;
                            }else{
                                medianay = img.imagen[mitady][mitady].valorIntensidad;
                            }
                        //}
                        //hacerporyeccion
                        hacer_proyeccion(p_i,p_j, medianay,imagenGenerada);
                        p_i++;
                        i++;
                        cont++;
                    }
                    p_j++;
                    p_i = 0;
                }
            }else{
                cout<<"Criterio no valido"<<endl;
                return false;
            }
        }else if (strcmp(direccion,"z")==0){
            imagenGenerada.W = volumen.volumen.front().W;
            imagenGenerada.H = volumen.volumen.size();
            imagenGenerada.imagen.resize(volumen.volumen.front().W);
            for(int i = 0; i<imagenGenerada.imagen.size();i++){
                imagenGenerada.imagen[i].resize(volumen.volumen.size());
            }
            if(strcmp(criterio,"minimo")==0){
                int p_k=0;
                p_j=0;
                //cont=0;
                int minimoZ=1000; //250 en el proyecto
                img = volumen.volumen[0];
                for(int i=0;i<img.imagen.size();i++){
                    cont=0;
                    int j=0;
                    while (cont!=img.imagen.size()){
                        for(int k=volumen.volumen.size()-1;k>=0;k--){
                            img=volumen.volumen[k];
                            if(img.imagen[i][j].valorIntensidad<minimoZ){
                                minimoZ=img.imagen[i][j].valorIntensidad;
                            }
                        }
                        hacer_proyeccion(p_k,p_j,minimoZ,imagenGenerada);
                        p_j++;
                        j++;
                        cont++;
                    }
                    p_k++;
                    p_j=0;
                }
            }else if(strcmp(criterio,"maximo")==0){
                int p_k=0;
                p_j=0;
                int maximoz=0;
                img = volumen.volumen[0];
                for(int i=0;i<img.imagen.size();i++){
                    cont=0;
                    int j=0;
                    while (cont!=img.imagen.size()){
                        for(int k=0; k<volumen.volumen.size();k++){
                            img=volumen.volumen[k];
                            if(img.imagen[i][j].valorIntensidad>maximoz){
                                maximoz=img.imagen[i][j].valorIntensidad;
                            }
                        }
                        hacer_proyeccion(p_k,p_j,maximoz,imagenGenerada);
                        p_j++;
                        j++;
                        cont++;
                    }
                    p_k++;
                    p_j=0;
                }
            }else if(strcmp(criterio,"promedio")==0){
                int p_k=0;
                p_j=0;
                int promedioz=0,sumaz=0;
                img = volumen.volumen[0];
                for(int i=0;i<img.imagen.size();i++){
                    cont=0;
                    int j=0;
                    while (cont!=img.imagen.size()){
                        for(int k=volumen.volumen.size()-1;k>=0;k--){
                            img=volumen.volumen[k];
                                sumaz+=img.imagen[i][j].valorIntensidad;
                        }
                        promedioz=sumaz/img.imagen.size();
                        promedioz=floor(promedioz);
                        hacer_proyeccion(p_k,p_j,promedioz,imagenGenerada);
                        p_j++;
                        j++;
                        cont++;
                    }
                    p_k++;
                    p_j=0;
                }
            }else if(strcmp(criterio,"mediana")==0){
                int p_k=0;
                p_j=0;
                int pos_medianaz=0, medianaz=0,pos_medianas=0;
                std::vector<int> medianas;
                img = volumen.volumen[0];
                for(int i=0;i<img.imagen.size();i++){
                    cont=0;
                    int j=0;
                    while (cont!=img.imagen.size()){
                        for(int k=volumen.volumen.size()-1;k>=0;k--) {
                            img = volumen.volumen[k];
                            int mitadz = img.imagen.size() / 2;
                            if (img.imagen.size() % 2 == 0) {
                                pos_medianaz = (mitadz + (mitadz + 1)) / 2;
                                medianas.push_back(img.imagen[pos_medianaz][pos_medianaz].valorIntensidad);
                            } else {
                                medianas.push_back(img.imagen[mitadz][mitadz].valorIntensidad);
                            }
                        }
                            int mitadMedianas=medianas.size()/2;
                            if(medianas.size()%2==0){
                                pos_medianas = (mitadMedianas+(mitadMedianas+1))/2;
                                medianaz = medianas[pos_medianas];
                            }else{
                                medianaz= medianas[mitadMedianas];
                            }
                        hacer_proyeccion(p_k,p_j,medianaz,imagenGenerada);
                        p_j++;
                        j++;
                        cont++;
                    }
                    p_k++;
                    p_j=0;
                }
            }else{
                cout<<"Criterio no valido"<<endl;
                return false;
            }
        }else{
            cout<<"Direccion no valida"<<endl;
            return false;
        }
        crearArchivo(nombre_archivo,imagenGenerada);
        return true;
    }
}