#ifndef EDD_TAD_VOLUMEN_H
#define EDD_TAD_VOLUMEN_H

#include <queue>
#include "TAD_imagen.h"

struct sVolumen {
    char nombreBase[100] = "";
    int cantidadImagenes  = 0;
    int H = 0;
    int W = 0;
    std::vector<sImagen>volumen;
};

bool cargarVolumen(char* nombreBase, struct sVolumen &volumen);

void infoVolumen(struct sVolumen &vol);

//bool proyeccion2D(char* comando,struct sVolumen &volumen1);

#endif //EDD_TAD_VOLUMEN_H
