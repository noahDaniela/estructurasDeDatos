#ifndef EDD_HUFFMAN_H
#define EDD_HUFFMAN_H

#include <string>
#include <map>
#include <unordered_map>
#include <queue>
#include <vector>
#include "TAD_imagen.h"
#include "TAD_pixel.h"
#include "Nodo.h"
/*
 • comando: codificar_imagen nombre_archivo.huffman
salida en pantalla:
(proceso satisfactorio) La imagen en memoria ha sido codificada exitosamente
(mensaje de error) No hay una imagen cargada en memoria
descripción: El comando debe generar el archivo de texto con la correspondiente codificación de
Huffman para la imagen que se encuentre actualmente cargada en memoria, almacenándolo en disco
bajo el nombre nombre_archivo.huffman .
• comando: decodificar_archivo nombre_archivo.huffman nombre_imagen.pgm
salida en pantalla:
(proceso satisfactorio) El archivo nombre_archivo.huffman ha sido decodificado exitosamente
(mensaje de error) El archivo nombre_archivo.huffman no ha podido ser decodificado
descripción: El comando debe cargar en memoria (en la estructura más adecuada) la información de
codificación contenida en el archivo nombre_archivo.huffman y luego debe generar la correspondiente
imagen decodificada en formato PGM, almacenándola en disco bajo el nombre nombre_imagen.pgm .
 */
struct comparar{
    bool operator()(Nodo* hijoIzq, Nodo* hijoDer){
        return hijoIzq->simbolo.frecuencia > hijoDer->simbolo.frecuencia;
    }
};
struct arbolHuffman{
    Nodo* raiz;
};

void decodificar(Nodo* raiz, int &i,std::string s,std::string &deco);
void codificar(Nodo* raiz, std::string codigo,std::unordered_map<int,std::string>&codigos);
void arbolHuffman(char* arc,struct  sImagen &imagen);
Nodo* crearNodo(int simbolo, int frecuencia, Nodo* hijoIzq, Nodo* hijoDer);
void escribir_Codificacion(char* arch,std::string nombre_archivo,struct sImagen &img,std::map<int,unsigned long>&imagenCargada);
void escribir_decodificacion(char* nomArch,sImagen &img,char* nomImg);
#endif //EDD_HUFFMAN_H