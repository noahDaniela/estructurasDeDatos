#ifndef EDD_TAD_IMAGEN_H
#define EDD_TAD_IMAGEN_H

#include <vector>
#include "Huffman.h"
#include "TAD_pixel.h"
using namespace std;

struct sImagen{
    char nombre[100] = "";
    char codigo[10];
    char idSerie[100];
    int W = 0; //ancho
    int H = 0; //alto
    int M= 0; //pixel Maximo
    std::vector< std::vector<sPixel> >imagen;
};

bool cargarImagen(char* archivo, struct sImagen &imagen);
void infoImagen(sImagen &imagen);
bool codificar_imagen(char* arch,struct sImagen &imagen);
bool decodificar_imagen(char *com,struct sImagen &imagen);
#endif //EDD_TAD_IMAGEN_H