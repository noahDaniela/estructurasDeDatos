#include "TAD_imagen.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include "cstdlib"
#include <cstring>

bool verificarExtension(string archivo) {
    size_t pos= archivo.find_last_of(".");
    if(archivo.substr(pos) == ".pgm"){
        return true;
    }else{
        return false;
    }
}

bool cargarImagen(char* archivo, struct sImagen &imagen) {

    int aux = 0;
    int i = 0;
    int contmatriz = 0;
    int posi = 0;
    int posj = 0;
    char ruta[20]="";
    string codigo, comentario, line = "", w, h, m, auxchar;
    strcat(ruta, archivo);
    //strcat(ruta, archivo);
     if(verificarExtension(archivo)){
    ifstream file(ruta);
    stringstream ss;
    if (file.is_open()) {
        getline(file, line);
        strcpy(imagen.codigo, line.c_str());
        ss << file.rdbuf();
        ss >> w;
        ss >> h;
        imagen.W = atoi(w.c_str());
        imagen.H = atoi(h.c_str());
        ss >> m; //tomar el valor del pixel
        aux = atoi(m.c_str());
        imagen.M = aux;
        imagen.imagen.resize(imagen.W);
        while (contmatriz != (imagen.H * imagen.W)) {
            i = 0;
            for (; i < imagen.imagen.size(); i++) {
                ss >> auxchar;
                aux = atoi(auxchar.c_str());
                sPixel pixelImagen;
                pixelImagen.pos_i = posi;
                pixelImagen.valorIntensidad = aux;
                pixelImagen.pos_j = posj;
                imagen.imagen[i].push_back(pixelImagen);
                posj++;
                contmatriz += 1;
            }
            posi++;
            posj = 0;
        }
        file.close();
        return true;
    } else {
        perror("Error ");
        return false;
    }
    }else{
         cout<<"El formato del archivo es incorrecto"<<endl;
         return false;
     }
 }

void infoImagen(sImagen &imagen){
    if(imagen.W==0&&imagen.H==0){
        cout<<" No hay una imagen cargada en memoria"<<endl;
    }else {
        cout << " Imagen cargada en memoria: ";
        cout << imagen.nombre << ", ";
        cout << " ancho: " << imagen.W << ", alto: " << imagen.H << endl;
    }
}

bool codificar_imagen(char* arch,struct sImagen &imagen){
    if(imagen.W==0&&imagen.H==0){
        cout<<" No hay una imagen cargada en memoria"<<endl;
        return false;
    }
    char nombre_archivo[20];
    strtok(arch, " ");
    strcpy(nombre_archivo, strtok(NULL, " "));
    arbolHuffman(nombre_archivo,imagen);
    return true;
}

bool decodificar_imagen(char *com,struct  sImagen &imagen){
    char nombre_archivo[50];
    char nombre_imagen[50];
    char ruta[20];
    strtok(com, " ");
    strcpy(nombre_archivo, strtok(NULL, " "));
    strcpy(nombre_imagen, strtok(NULL, " "));
    strcpy(ruta, "../");
    strcat(ruta, nombre_archivo);
    ifstream file(nombre_archivo);
    if (file.is_open()){
        escribir_decodificacion(nombre_archivo,imagen,nombre_imagen);
        file.close();
        return true;
    }else{
      perror("Error ");
      return false;
    }
}