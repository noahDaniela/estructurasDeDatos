#ifndef EDD_NODO_H
#define EDD_NODO_H
#include "TAD_pixel.h"

struct Nodo{
    struct sPixel simbolo; //valor de intensidad
    Nodo* hijoIzq;
    Nodo* hijoDer;
};

bool esHoja(Nodo* nod);
void fijarHijoIzq(Nodo* izq);
void fijarHijoDer(Nodo* der);
Nodo* obtenerHijoIzq();
Nodo* obtenerHijoDer();

#endif