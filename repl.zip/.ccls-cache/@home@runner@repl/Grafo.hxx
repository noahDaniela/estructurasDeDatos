
#include "Grafo.h"
#include<iterator>
#include<vector>
#include<iostream>
#include<stack>
#include<queue>
#include <functional>
template <class T, class U>
Grafo<T, U>::Grafo(){}

template <class T, class U>
        std::vector<T> Grafo<T,U>::obtenerVertices(){
    return this->vertices;
}

template <class T, class U>
        vector<  vector < Arista<U> > > Grafo<T, U>::obtenerAristas(){
    return this->aristas;
}
template <class T, class U>
void Grafo<T, U>:: fijarVertices(vector<T> vertices){
    this->vertices = vertices;

}
template <class T, class U>
void Grafo<T, U>:: fijarAristas(vector < vector <Arista <U> > > aristas){
    this->aristas = aristas;
}
template <class T, class U>
int Grafo<T, U>::cantidadVertices(){
    return this->vertices.size();
}
template <class T, class U>
int Grafo<T, U>:: cantidadAristas(){
    int totalAristas = 0;
    for(int i = 0; i< this->vertices.size(); i++){
        totalAristas += this->vertices[i].size();
    }
    return totalAristas;
}
template <class T, class U>
bool Grafo<T, U>::compararVertices(Vertice<T> v1, Vertice<T> v2){
    bool iguales = false;
    if(v1->obtenerDato() == v2->obtenerDato()){
        iguales = true;
    }
    return iguales;
}

template <class T, class U>
bool Grafo<T, U>::buscarVertice(Vertice<T> vertice){
    typename vector<Vertice<T>>::iterator it;
    for(it = this->vertices.begin(); it != this->vertices.end(); it++){
        if(compararVertices(*it, vertice)){
            return true;
        }
    }
    return false;
}

template <class T, class U>
bool Grafo<T, U>::insertarVertice(Vertice<T> vertice){
    if(buscarVertice(vertice)){
        return false;
    }else{
        this->vertices.push_back(vertice);
        vector <Arista<U>> nuevo;
        aristas.push_back(nuevo);
        return true;
    }
}

template <class T, class U>
        T Grafo<T, U>::obtenerVertice(int indice){
    typename vector<T>::iterator it;
    it = this->vertices.begin();
    advance(it, indice);
    return *it;
}

template <class T, class U>
bool Grafo<T, U>:: insertarArista( int i1, int i2, int costo){
    typename vector< vector < Arista<U>>  > ::iterator itgen;
    typename vector<  Arista<U>  > ::iterator itAristas;
    bool conexion = false;
    itgen = this->aristas.begin();
    advance(itgen, i1);
    itAristas = itgen.begin();
    for( ; itAristas != itgen->end(); itAristas++){
        if(i2 == (itAristas)->obtenerIndice()){
            conexion = true;
        }
    }
    if(!conexion){
        Arista<int>newArista(costo, i2);
        itgen->push_back(newArista);
    }
    return conexion;
}

template <class T, class U>
int Grafo<T, U>::obtenerIndiceVert(Vertice<T> vertice){
    int indice = 0;
    for(int i = 0; i< this->vertices.size(); i++){
        if(vertices[i].obtenerDato() == vertice.obtenerDato()){
            indice = i;
        }
    }
  return indice;
}
template <class T, class U>
bool Grafo<T, U>::buscarArista(Vertice<T> origen, Vertice<T> destino){
    bool encontrado = false;
    int indice = obtenerIndiceVert(destino);
    typename vector<  Arista<U>  > ::iterator itAr;
   // int indice = 0;
    if(buscarVertice(origen) && buscarVertice(destino)){
        for(int i = 0;i < this->vertices.size(); i++){
            if(compararVertices(vertices[i], origen)){
                itAr = vertices[i].begin();
                for( ; itAr != vertices[i].end(); itAr++){
                    if((*itAr)->obtenerIndice() == indice){
                        destino = true;
                    }
                }
            }
        }

    }
    return encontrado;
}
template <class T, class U>
void Grafo<T, U>::eliminarVertice(Vertice<T> v){
    typename vector<Vertice<T>>::iterator it;
    typename vector<  Arista<U>  > ::iterator itAr;
    int indice = 0;
    if(buscarVertice(v)){
        indice = obtenerIndiceVert(v);
        advance(it, indice);
        it.clear();
        itAr = this->vertices.begin();
        for(int i = 0; i< this->vertices.size();i++){
            itAr = vertices[i].begin();
            for( ; itAr != vertices[i].end(); itAr++){
                if((itAr)->ObtenerIndice() == indice){
                    vertices[i].remove(itAr);
                }
            }
        }
        this->vertices.erase(indice);
    }
}
template <class T, class U>
void Grafo<T, U>::eliminarArista(Vertice<T> origen, Vertice<T> destino){
    typename vector<  Arista<U>  > ::iterator it;
    typename vector<Vertice<T>>::iterator it2;
    int indice = 0;
    int indiceDest = obtenerIndiceVert(destino);
    if(buscarVertice(origen) && buscarVertice(destino)){
        indice = obtenerIndiceVert(origen);
        advance(it2, indice);
        it = it2.begin();
        for( ; it != it2.end(); it++){
            if((it)->obtenerIndice() == indiceDest){
                it2.remove(it);
            }
        }
    }
}
    template <class T, class U>
    void Grafo<T, U>::recorridoPlano(){
        typename vector<Vertice<T>>::iterator it;
        it = this->vertices.begin();
        std::cout<<"Recorrido plano: "<<endl;
        for( ; it != this->vertices.end(); it++){
            cout<<*it->obtenerDato()<<endl;
        }
    }
    template <class T, class U>
    void Grafo<T, U>::recorridoProfundidad(){
        typename vector< Arista<U> > ::iterator itA;
        std::vector<Vertice<T>> verticesVisitados;
        std::stack<Vertice<T>> s;
        s.push(this->vertices.front());
        while(!s.empty()){
            if(!verticesVisitados.find(s.top())){
                verticesVisitados.push_back(s.top());
            }
            itA = s.top().begin();
            for( ; itA != s.top.end(); itA++){
                Vertice<T> vert = obtenerVertice((itA)->obtenerIndice());
                s.push_back(vert);
            }
            s.pop();
        }
        std::cout<<"recorrido en profundidad"<<endl;
        for (int i = 0; i<verticesVisitados.size(); i++){
            std::cout<<verticesVisitados[i].obtenerDato();
        }
    }


    template <class T, class U>
    void Grafo<T, U>::prim(Vertice<T> inicio){ //para costos negativos
        Vertice<T> actual = inicio;
        int menorCosto = 100000;
        int indiceVertice;
        int indiceRuta;
        typename vector<Arista<U> >::iterator it;
        typename vector< vector <Arista<U> > >::iterator itv;
        vector<Vertice<T>> Vnew;
        vector< pair< Vertice<T>, Vertice<T>> > Enew;
        Vertice<T> aux;
        while(Vnew.size() != this->vertices.size()){
            indiceVertice = obtenerIndiceVert(actual);
            advance(itv, indiceVertice);
            it = itv->begin();
            Vnew.push_back(actual); //tomamos el vertice d einicio y lo agregamos al nuevo vector
            for( ; it != itv->end(); it++){ //verificamos las aristas de menos costo del vertice
                if((it)->ObtenerPeso()<menorCosto){
                    menorCosto = (it->ObtenerPeso());
                    indiceRuta = (it)->ObtenerIndice();
                }
            }
            //aqui ya tenemos el vertice y la arista con menor costo
            aux = obtenerVertice(indiceRuta);
            Vnew.push_back(aux);
       //     Enew.push_back(pair(actual, aux)); //agregamos al vecvtor de aristas el par de aristas conectadas por ese menor costo
            actual = aux;
        }
        std::cout<<"ALGORITMO PRIM"<<endl;
        for (int i = 0; i<Vnew.size(); i++){
            std::cout<<Vnew[i].obtenerDato();
        }
    }

    template <class T, class U>
    void Grafo<T, U>::dijkstra(int indiceInicio){ //sin cola de prioridad
        std::vector<int> dist;
        std::vector<Vertice<T>>pred;
        std::vector<int>s;     //1 visitado, 0 no visitado
        //std::queue<Vertice> q;
        int costo = 0;
        int iteraciones = 1;
        //redimensionamos todos los vectores
        dist.resize(this->vertices.size());
        pred.resize(this->vertices.size());
        s.resize(this->vertices.size());
        //q.resize(this->vertices.size());

        Vertice<T> verticeHallado = obtenerVertice(indiceInicio);

        //1. inicializar vector de distancias con infinito
        for(int i = 0; i<dist.size(); i++){
            dist[i] = 10000;
        }

        if(verticeHallado != NULL){
            pred[indiceInicio] = verticeHallado;
            do{
                int indiceVerticeHallado = obtenerIndiceVert(verticeHallado); //3
                s[indiceVerticeHallado] = 1;
                dist[indiceVerticeHallado] = costo;
                typename vector< vector <Arista<U> > >::iterator it1;
                typename vector< Arista<U> >::iterator it2;
                advance(it1, indiceVerticeHallado);
                it2 = it1->begin();
                for( ; it2 != it1->end();it2++){
                    costo = dist[indiceVerticeHallado];
                    int costoAux = costo + (*it2)->ObtenerPeso();
                    int ind = (*it2)->ObtenerIndice();
                    if(dist[ind]>costoAux){
                        pred[ind] = verticeHallado;
                        dist[ind] = costoAux;
                    }
                }

                //1. recorrer el vector de dist y mirar el vertice que tenga menor costo de distancia
                //2. con su indice, obtener el vertice a traves de obtenerIndiceVert
                //3. actualizar el indice hallado y volver a repetir el proceso
                int menor = 99999;
                Vertice<T> vertAux = NULL;
                for(int i = 0; i<dist.size(); i++){
                    if(dist[i]<menor && s[i] != 1){ //si es la menor distancia y no esta visitado
                        menor = dist[i];
                        vertAux = obtenerVertice(i);
                    }
                }

                verticeHallado = vertAux;
                costo = menor;

                iteraciones +=1;
            } while(iteraciones <= this->vectores.size());
        }//el del if
    }

  /*
Template <class T, class U>
  void Grafo<T, U>::dijkstra(int indiceInicio){
  std::vector<int> dist;
  std::vector<Vertice>pred;
  std::visitados<int>s;     //1 visitado, 0 no visitado
  std::queue<Vertice> q;
  int costo = 0;
    //redimensionamos todos los vectores
    dist.resize(this->vertices.size());
    pred.resize(this->vertices.size());
    s.resize(this->vertices.size());
    q.resize(this->vertices.size());

    Vertice verticeHallado = obtenerVertice(indiceInicio);
  
    //1. inicializar vector de distancias con infinito
    for(int i = 0; i<dist.size(); i++){
      dist[i] = 99999;
    }

    if(verticeHallado){
      do{
        int indiceVerticeHallado = obtenerIndiceVert(verticeHallado);
        q.push(verticeHallado);
        s[indiceVerticeHallado] = 1;
        dist[indiceVerticeHallado] = costo;
        vector< vector <Aristas<U> > >::iterator it1;
        vector< Aristas<U> >:iterator it2;
        advance(it1, verticeHallado->ObtenerIndice());
        it2 = it1->begin();
        for( ; it2 != it1->end();it2++){
          float costoAux = costo + (*it2)->ObtenerPeso();
          int ind = (*it2)->ObtenerIndice();
          if(dist[ind]>precioAux){
            pred[ind] = verticeHallado;
            dist[ind] = costoAux;
          }
        }
        int menor = 99999;
        for(int i = 0; i<this->vetices.size();i++){
          Vertice<T> verticeAux = obtenerVertice(indiceInicio);
          if(menor>dist[i] && s[indiceVerticeHallado] != 1){
            menor = dist[i];
            vertice = dist[i];
          }
        }

        Costo = menor;
      } while(nodo);
    }//el del if
}

*/
