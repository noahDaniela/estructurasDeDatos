#ifndef EDD_TAD_PROYECCION_H
#define EDD_TAD_PROYECCION_H

#include "TAD_volumen.h"

void hacer_proyeccion(int &a, int &b, int &valor);
bool proyeccion2D(char* comando, struct sVolumen &volumen);

    //llamar la funcion que sea necesaria

#endif //EDD_TAD_PROYECCION_H

