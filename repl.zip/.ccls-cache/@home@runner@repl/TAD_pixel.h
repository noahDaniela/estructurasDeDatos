#ifndef EDD_TAD_PIXEL_H
#define EDD_TAD_PIXEL_H
struct sPixel {
    int valorIntensidad;
    int frecuencia=0;
    int pos_i=0;
    int pos_j=0;
};
#endif //EDD_TAD_PIXEL_H
