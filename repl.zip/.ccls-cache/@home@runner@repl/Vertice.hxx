#include "Vertice.h"

template <class T>
Vertice<T>::Vertice(){}

template <class T>
T Vertice<T>::ObtenerDato(){
    return this->dato;
}
template <class T>
void Vertice<T>::fijarDato(T dato){
    //new Vertice
    this->dato = dato;
}