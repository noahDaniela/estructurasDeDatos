#ifndef __ARISTA_H__
#define __ARISTA_H__
using namespace std;
template <class T>
class Arista{
private:
    T peso;
    int indice; //indice de vértice
public:
    Arista();
    Arista(T peso, int indice);
    T ObtenerPeso();
    void fijarPeso(T peso);
    int ObtenerIndice();
    void fijarIndice(int indice);
};

#include "Arista.hxx"
#endif