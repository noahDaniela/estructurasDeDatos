#include "Arista.h"
//using namespace std;

template <class T>
Arista<T>::Arista(){}

template <class T>
Arista<T>::Arista (T peso , int indice){
    this->peso = peso;
    this->indice = indice;
}

template <class T>
T Arista<T>::ObtenerPeso(){
    return this->peso;
}

template <class T>
void Arista<T>::fijarPeso (T peso){
    this->peso = peso;
}
template <class T>
int Arista<T>::ObtenerIndice(){
    return this->indice;
}
template <class T>
void Arista<T>::fijarIndice(int indice){
    this->indice = indice;
}



