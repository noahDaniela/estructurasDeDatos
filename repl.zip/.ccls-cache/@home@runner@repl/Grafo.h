
#ifndef __GRAFO_H__
#define __GRAFO_H__
#include  "Vertice.h"
#include "Arista.h"
#include <vector>
//using namespace std;

template <class T, class U>
class Grafo{
private:
    vector<Vertice<T>> vertices;
    vector< vector <Arista<U> > >  aristas;
public:
    Grafo();
    std::vector <T>  obtenerVertices();
    vector<  vector < Arista<U>>  > obtenerAristas();
    void fijarVertices( vector <T> vertice);
    void fijarAristas( vector<  vector < Arista<U> >  > arista);
    int cantidadVertices();
    int cantidadAristas();
    bool compararVertices(Vertice<T> v1, Vertice<T> v2);
    bool buscarVertice(Vertice<T> vertice);
    bool insertarVertice(Vertice<T> newVertice);
    T obtenerVertice(int indice);
    bool insertarArista(int i1, int i2, int peso);
    bool buscarArista(Vertice<T> origen, Vertice<T> destino);
    void eliminarVertice(Vertice<T> vertice);
    int obtenerIndiceVert(Vertice<T> vertice);
    void eliminarArista(Vertice<T> origen, Vertice<T> destino);
    void recorridoPlano();
    void recorridoProfundidad();
    void recorridoAnchura();
    void prim(Vertice<T>);
    void dijkstra(int indiceInicio);
};


#include "Grafo.hxx"
#endif