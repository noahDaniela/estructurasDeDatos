/*
    Grupo 6
-Noah Daniela Jaime
-Angie Katherine Castro
*/

#include <iostream>
#include <cstring>
#include "TAD_imagen.h"
#include "TAD_volumen.h"
#include "TAD_proyeccion.h"
#include "Grafo.h"
using namespace std;

struct comandos{
    int num;
    char *palabra=new char [20];
    int num_argumentos;
};
comandos com[10];

void llenar(){
    com[0].num=1;
    strcpy(com[0].palabra,"cargar_imagen");
    com[0].num_argumentos = 2;
    com[1].num=2;
    strcpy(com[1].palabra,"cargar_volumen");
    com[1].num_argumentos = 3;
    com[2].num=3;
    strcpy(com[2].palabra,"info_imagen");
    com[2].num_argumentos = 1;
    com[3].num=4;
    strcpy(com[3].palabra,"info_volumen");
    com[3].num_argumentos = 1;
    com[4].num=5;
    strcpy(com[4].palabra,"proyeccion2D");
    com[4].num_argumentos = 4;
    com[5].num=6;
    strcpy(com[5].palabra,"codificar_imagen");
    com[5].num_argumentos = 2;
    com[6].num=7;
    strcpy(com[6].palabra,"decodificar_archivo");
    com[6].num_argumentos = 3;
    com[7].num=8;
    strcpy(com[7].palabra,"segmentar");
    com[7].num_argumentos = 5;
    com[8].num=9;
    strcpy(com[8].palabra,"ayuda");
    com[8].num_argumentos = 2;
    com[9].num=10;
    strcpy(com[9].palabra,"salir");
    com[9].num_argumentos = 1;
}

void ayuda(){
    cout<<endl<<"  Comando\t[parametros]"<<endl;
    cout<<endl<<"  cargar_imagen\t[nombre_imagen.pgm]"<<endl;
    cout<<"  cargar_volumen\t[nombre_base][n_im]"<<endl;
    cout<<"  info_imagen"<<endl;
    cout<<"  info_volumen"<<endl;
    cout<<"  proyeccion2D\t[direccion] [criterio] [nombre_archivo.pgm]"<<endl;
    cout<<"  codificar_imagen\t[nombre_archivo.huffman]"<<endl;
    cout<<"  decodificar_archivo\t[nombre_archivo.huffman] [nombre_imagen.pgm]"<<endl;
    cout<<"  segmentar\t[salida_imagen.pgm] [sx1] [sy1] [sl1] [sx2] [sy2] [sl2]..."<<endl;
    cout<<"  ayuda [comando] si desea conocer la descripciÃ›n del comando"<<endl;
    cout<<"  salir"<<endl;

}
int numero(char* pal){
    for(int i=0;i<10;i++){
        if(strcmp(pal,com[i].palabra)==0){
            return com[i].num;
        }
    }
    return 0;
}

void ayuda_comando(char* comando){
    if(strcmp(comando,"cargar_imagen")==0 ){
        cout<<"El comando debe cargar en memoria la imagen identificada con el nombre_imagen.pgm. Una vez cargada la informacion en memoria, el comando debe mostrar elmensaje de carga satisfactoria"<<endl;
    }else if(strcmp(comando, "cargar_volumen")==0){
        cout<<"El comando debe cargar en memoria  la serie ordenada de imagenes identificada con el nombre_base y cuyo tamano corresponde a n_im imagenes (la serie podra tener maximo 99 imagenes).  Todas las imagenes de la serie deben estar nombradas como nombre_basexx.pgm, donde xx corresponde a dos digitos de identificacion de la posicion de la imagen en la serie (varia en el rango 01-n_im). Una vez cargada toda la informacion en memoria, el comando debe mostrar el mensaje de carga satisfactoria. Si por alguna razon no es posible cargar completamente la serie ordenada de imagenes (nombre de base erroneo, cantidad de imagenes no corresponde, error en alguna imagen), el comando debe mostrar el mensaje de error"<<endl;
    }else if(strcmp(comando,"info_imagen")==0){
        cout<<"El comando debe mostrar en pantalla la informacion basica de la imagen actualmente cargada en memoria: nombre de archivo, ancho en pixeles y alto en pixeles. Si no se ha cargado aun una imagen en memoria, el comando debe mostrar el mensaje de error."<<endl;
    }else if(strcmp(comando,"info_volumen")==0){
        cout<<"El comando debe mostrar en pantalla la informacion basica de la serie de imagenes (volumen) cargadas actualmente en memoria: nombre base, cantidad de imagenes, ancho en pixeles y alto en pixeles. Si no se ha cargado ningun un volumen en memoria, el comando debe mostrar el mensaje de error."<<endl;
    }else if(strcmp(comando,"proyeccion2D")==0){
        cout<<"El comando debe tomar la serie ordenada de imagenes, y de acuerdo a la direccion especificada por el usuario, debe recorrer cada posicion en el plano perpendicular a la direccion dada, y para cada una debe colapsar toda la informacion existente en la direccion dada utilizando el criterio especificado.  Esto genera un solo valor de pixel para cada posicion del plano perpendicular, generando asi una imagen 2D con la proyeccion de la informacion en el volumen. La direccion puede ser una entre x (en direccion de las columnas), y (en direccion de las filas) o z (en direccion de la profundidad). El criterio puede ser uno entre minimo (el valor minimo de intensidad), maximo (el valor maximo de intensidad), promedio (el valor promedio de intensidad) o mediana (el valor mediana de intensidad). Una vez generada la proyeccion, debe guardarse como imagen en formato PGM como nombre_archivo.pgm. Es importante anotar que este comando solo puede funcionar sobre volumenes (series de imagenes)"<<endl;
    }else if(strcmp(comando,"codificar_imagen")==0){
        cout<<"El comando debe generar el archivo de texto con la correspondiente codificacion de Huffman para la imagen que se encuentre actualmente cargada en memoria, almacenandolo en discobajo el nombre nombre_archivo.huffman"<<endl;
    }else if(strcmp(comando,"decodificar_archivo")==0){
        cout<<"El comando debe cargar en memoria la informacion decodificacion contenida en el archivonombre_archivo.huffmany luego debe generar la correspondiente imagen decodificada en formato PGM, almacenandola en disco bajo el nombrenombre_imagen.pgm."<<endl;
    }else if(strcmp(comando,"segmentar")==0){
        cout<<"El comando debe cargar la informacion del conjunto de semillas correspondiente a la imagen cargada en memoria, para luego proceder a su segmentacion de acuerdo al algoritmo presentado anteriormente. La imagen con las etiquetas debe quedar guardada en salida_imagen.pgm"<<endl;
    }else{
        cout<<"El comando no existe"<<endl;
    }
}
bool verificarParametros(char* temp,int pos){
    char *aux2 = new char[50];
    char *aux3 = new char[50];
    int i=0;
    aux2=strtok(temp," ");
    while(aux2!=NULL)
    {
        //  aux2=strtok(NULL," ");
        if(aux2!=NULL){
            strcpy(aux3,aux2);
        }
        aux2=strtok(NULL," ");
        i++;
    }
    strcpy(temp,aux3);
    if(pos==7){
        if(i>=com[pos].num_argumentos)
            return true;
        return false;
    }
    if(pos==8){
        if(i == 2){
            ayuda_comando(aux3);
            return true;
        }else if(i==1){
            ayuda();
            return true;
        }
    }
    else if(i==com[pos].num_argumentos)
        return true;
    return false;
}

int main() {
    sImagen imagen;
    sVolumen volumen;
    string archivo;
    llenar();

    bool continuar= true;
    cout<<"Digite un comando para iniciar"<<endl;
    cout<<endl;
    cout<<"******Para mas informacion sobre los comandos digite el comando ayuda******"<<endl;
    do{
        cout<<"$";
        char *pal=new char[100];
        char *aux=new char[100];
        char *temp = new char[100];
        string tmp_string;
        cin.getline(pal, 100, '\n');
        strcpy(aux,pal);
        char *token = strtok(aux," ");
        int n=numero(token);
        switch(n){
            case 1:
                strcpy(temp,pal);
                if(verificarParametros(temp,0)){
                    strcpy(imagen.nombre,temp);
                    if(cargarImagen(temp, imagen)){
                        cout<<" La imagen "<<temp<<" ha sido cargada."<<endl;
                    }else{
                        cout<<" No se ha cargado una imagen en memoria."<<endl;
                    }
                }else{
                    cout<<"argumentos no validos"<<endl;
                }
                break;
            case 2:
                strcpy(temp,pal);
                if(verificarParametros(temp,1)){
                    if(cargarVolumen(pal, volumen)){
                        cout<<"\n El volumen "<<volumen.nombreBase<<" ha sido cargado."<<endl;
                    }else{
                        cout<<"\n El volumen "<<volumen.nombreBase<<" NO ha sido cargado."<<endl;
                    }
                }else{
                    cout<<"argumentos no validos"<<endl;
                }
                break;
            case 3:
                strcpy(temp,pal);
                if(verificarParametros(temp,2)){
                    infoImagen(imagen);
                }else{
                    cout<<"argumentos no validos"<<endl;
                }
                break;
            case 4:
                strcpy(temp,pal);
                if(verificarParametros(temp,3)){
                    infoVolumen(volumen);
                }else{
                    cout<<"argumentos no validos"<<endl;
                }
                break;
            case 5:
                strcpy(temp,pal);
                if(verificarParametros(temp,4)){
                    if(proyeccion2D(pal,volumen)){
                        cout<<"La proyeccion 2D del volumen en memoria ha sido generada"<<endl;
                    }else{
                        cout<<"La proyeccion 2D del volumen en memoria NO ha podido ser generada"<<endl;
                    }
                }else{
                    cout<<"argumentos no validos"<<endl;
                }
                break;
            case 6:
                strcpy(temp,pal);
                if(verificarParametros(temp,5)){
                    if(codificar_imagen(pal,imagen)){
                        cout<<" La imagen en memoria ha sido codificada exitosamente.\n";
                    }else{
                        cout<<" No hay una imagen cargada en memoria.\n ";
                    }
                }else{
                    cout<<"argumentos no validos"<<endl;
                }
                break;
            case 7:
                strcpy(temp,pal);
                if(verificarParametros(temp,6)){
                    if(decodificar_imagen(pal,imagen)){
                        cout<<"\nEl archivo ha sido decodificado exitosamente."<<endl;
                    }else{
                        cout<<"\nEl archivo no ha podido ser decodificado."<<endl;
                    }
                }else{
                    cout<<"argumentos no validos"<<endl;
                }
                break;
            case 8:
                strcpy(temp,pal);
                if(verificarParametros(temp,7)){
                    cout<<" La imagen fue segmentada correctamente\n"<<endl;
                }else{
                    cout<<"argumentos no validos"<<endl;
                }
                break;
            case 9:
                strcpy(temp,pal);
                if(verificarParametros(temp,8)){
                    break;
                }else{
                    cout<<"argumentos no validos"<<endl;
                }
                break;
            case 10:
                cout<<" Saliendo..."<<endl;
                continuar=false;
                break;
            default:
                cout<<" "<<pal<<" no existe, por favor inserte un comando valido."<<endl;
                break;
        }
    }while(continuar);
}