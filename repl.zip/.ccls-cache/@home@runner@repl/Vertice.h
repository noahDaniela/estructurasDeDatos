#ifndef __VERTICE_H__
#define __VERTICE_H__

using namespace std;
#include<list>
template <class T>
class Vertice{
private:
    T dato;
public:
    Vertice();
    T ObtenerDato();
    void fijarDato(T dato);
};

#include "Vertice.hxx"
#endif