#include "TAD_volumen.h"
#include "TAD_imagen.h"
#include <cstring>
#include <string>
#include <fstream>
#include <iostream>

/*bool crearArchivo(char* nombreA,sImagen &imagenG){
    ofstream nuevoArch;
    char nombre[20];
    strcpy(nombre,"../");
    strcat(nombre,nombreA);
    nuevoArch.open(nombre);
    nuevoArch << "P2\n";
    nuevoArch << imagenG.W;
    nuevoArch << " ";
    nuevoArch<< imagenG.H;
    nuevoArch << "\n255\n";
    return true;
}*/

bool cargarVolumen(char* nombreBase, struct sVolumen &volumen ){
    char aux[100];
    int cantiImg=0;
    strtok(nombreBase, " ");
    strcpy(volumen.nombreBase, strtok(NULL, " "));
    strcpy(aux, strtok(NULL, " "));
    cantiImg  = atoi(aux);
    int i=1;
    if(cantiImg<=99){
        while (i!=cantiImg+1){
            sImagen imagenV;
            char nomArch[100] = "";
            strcpy(nomArch,volumen.nombreBase);
            if(i<10){
                strcat(nomArch,"0");
                strcat(nomArch,  to_string(i).c_str());
            }else {
                strcat(nomArch,  to_string(i).c_str());
            }
            i++;
            strcat(nomArch,".pgm");
            strcpy(imagenV.idSerie,nomArch);
            if(!cargarImagen(nomArch, imagenV)){
                return false;
            }
            volumen.volumen.push_back(imagenV);
        }
        volumen.cantidadImagenes=cantiImg;
        volumen.W=volumen.volumen.back().W;
        volumen.H=volumen.volumen.back().H;
        return true;
    }else{
        return false;
    }
}

void infoVolumen(struct sVolumen &vol){
    if(vol.cantidadImagenes == 0){
        std::cout<<" No hay un volumen cargado en memoria"<<endl;
    }else {
        std:: cout << " Volumen cargado en memoria: ";
        std:: cout << " Base: "<<vol.nombreBase << ", tamano: "<<vol.cantidadImagenes<<", ancho: "<<vol.W<<", alto: "<<vol.H<<endl;
    }
}