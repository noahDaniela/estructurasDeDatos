#include "Nodo.h"
#include <cstring>
bool esHoja(Nodo* raiz){
     if(raiz->hijoIzq == NULL && raiz->hijoDer == NULL ){
         return true;
     }
    return false;
}

void fijarHijoIzq(Nodo* padre,Nodo* izq){
    padre->hijoIzq=izq;
}

void fijarHijoDer(Nodo* padre,Nodo* der){
    padre->hijoDer=der;
}

Nodo* obtenerHijoIzq(Nodo* nodo){
    return nodo->hijoIzq;
}

Nodo* obtenerHijoDer(Nodo* nodo){
    return nodo->hijoDer;
}
