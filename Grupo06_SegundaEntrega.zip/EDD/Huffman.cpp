/*
 • comando: codificar_imagen nombre_archivo.huffman
salida en pantalla:
(proceso satisfactorio) La imagen en memoria ha sido codificada exitosamente
(mensaje de error) No hay una imagen cargada en memoria
descripción: El comando debe generar el archivo de texto con la correspondiente codificación de
Huffman para la imagen que se encuentre actualmente cargada en memoria, almacenándolo en disco
bajo el nombre nombre_archivo.huffman .
• comando: decodificar_archivo nombre_archivo.huffman nombre_imagen.pgm
salida en pantalla:
(proceso satisfactorio) El archivo nombre_archivo.huffman ha sido decodificado exitosamente
(mensaje de error) El archivo nombre_archivo.huffman no ha podido ser decodificado
descripción: El comando debe cargar en memoria (en la estructura más adecuada) la información de
codificación contenida en el archivo nombre_archivo.huffman y luego debe generar la correspondiente
imagen decodificada en formato PGM, almacenándola en disco bajo el nombre nombre_imagen.pgm .
 */

#include "Huffman.h"
#include <iostream>
#include "TAD_imagen.h"
#include <map>
#include <queue>
#include <cstring>
#include <fstream>
#include <unordered_map>

std::string decoficacion;
Nodo* crearNodo(int simbolo, int frecuencia, Nodo* hijoIzq, Nodo* hijoDer){
    Nodo* nuevoNodo = new Nodo();
    nuevoNodo->simbolo.valorIntensidad = simbolo;
    nuevoNodo->simbolo.frecuencia = frecuencia;
    nuevoNodo->hijoIzq = hijoIzq;
    nuevoNodo->hijoDer = hijoDer;
    return nuevoNodo;
}

void codificar(Nodo* raiz, std::string codigo,unordered_map<int,std::string>&codigos) {
    if (raiz == NULL) {
        return;
    }
    if (esHoja(raiz)) {
        codigos[raiz->simbolo.valorIntensidad] = codigo;
    }
    codificar(raiz->hijoIzq, codigo + "0", codigos);
    codificar(raiz->hijoDer, codigo  + "1", codigos);
}

void decodificar(Nodo* raiz, int &i,std::string cod,std::string &decodificacion) {
    if (raiz == NULL) {
        return;
    }
    if (esHoja(raiz)) {
        //std::cout<<raiz->simbolo.valorIntensidad;
        decodificacion += to_string(raiz->simbolo.valorIntensidad);
        return;
    }
    i++;
    if (cod[i] == '0') {
        decodificar(raiz->hijoIzq, i,cod,decodificacion);
    } else {
        decodificar(raiz->hijoDer, i,cod,decodificacion);
    }
}

void arbolHuffman(char* nomArch,sImagen &imagen){
    string cod="";
    std::map<int,unsigned long> imagenCargada;
    for( int i = 0; i<imagen.imagen.size();i++){
        for(int j = 0; j <imagen.imagen[i].size();j++){
            int key = imagen.imagen[i][j].valorIntensidad;
            imagenCargada[key]++;
            }
        }
    //cola de prioridad
    priority_queue<Nodo*,vector<Nodo*>,comparar> colaPrioridad;
    for(auto pair:imagenCargada){
        colaPrioridad.push(crearNodo(pair.first,pair.second,NULL,NULL));
    }
    while(colaPrioridad.size() != 1){
        Nodo* izq = colaPrioridad.top();
        colaPrioridad.pop();
        Nodo* der = colaPrioridad.top();
        colaPrioridad.pop();
        int suma = izq->simbolo.frecuencia + der->simbolo.frecuencia;
        colaPrioridad.push(crearNodo(-0,suma,izq, der));
    }
    Nodo* raiz = colaPrioridad.top();
    std::unordered_map<int,string> codigosHuffman;
    codificar(raiz,"",codigosHuffman);
    //codificar(raiz,"");
    /*cout<<"\nLos codigos de Huffman son: \n";
    for(auto pair:algoritmoHuffman){
        cout<<pair.first<<" "<<pair.second<<"\n";
    }*/

    for( int i = 0; i<imagen.imagen.size();i++) {
        for (int j = 0; j < imagen.imagen[i].size(); j++) {
            string aux(codigosHuffman[imagen.imagen[i][j].valorIntensidad]);
            cod += codigosHuffman[imagen.imagen[i][j].valorIntensidad];
        }
    }

    //cout<<"codificacion de la imagen es: "<<cod<<endl;
    escribir_Codificacion(nomArch,cod,imagen,imagenCargada);
    int i=-1;
    string deco="";
    while(i<(int)cod.size()-2) {
        decodificar(raiz, i,cod,deco);
    }
    cout<<endl;
    decoficacion=deco;
    cout<<"\nEl texto decodificado es:"<<decoficacion;
}
void escribir_decodificacion(char* nomArch,sImagen &img,char* nomImg){
    cout<<"\nEl texto decodificado es2:"<<decoficacion;
    ofstream nuevoArch;
    char nombre[50];
    //strcpy(nombre,"../");
    //strcat(nombre,nomImg);
    nuevoArch.open(nomImg);
    nuevoArch << "P2\n";
    nuevoArch << img.W;
    nuevoArch << " ";
    nuevoArch<< img.H;
    nuevoArch << "\n255\n";
    nuevoArch <<decoficacion;
    nuevoArch <<"\n";
    nuevoArch.close();
}
void escribir_Codificacion(char* nombre_archivo,std::string codi,sImagen &img,map<int,unsigned long>&imagenCargada){
    char nombre[50];
    //strcpy(nombre,"../");
   // strcat(nombre,nombre_archivo);
    ofstream nuevoArch(nombre_archivo,ios::binary);
    nuevoArch << img.W;
    nuevoArch << " ";
    nuevoArch<< img.H;
    nuevoArch << "\n";
    nuevoArch << img.M;
    nuevoArch << "\n";
    for(auto pair:imagenCargada){
        nuevoArch << pair.second;
        nuevoArch << " ";
    }
    nuevoArch << codi;
    nuevoArch.close();
}